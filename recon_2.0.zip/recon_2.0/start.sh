#! /bin/bash

HOMEDIR=`dirname $0`

cd $HOMEDIR
java -Xmx1024M -Dlog4j.configuration=file:conf/log4j.cfg -jar recon.jar 